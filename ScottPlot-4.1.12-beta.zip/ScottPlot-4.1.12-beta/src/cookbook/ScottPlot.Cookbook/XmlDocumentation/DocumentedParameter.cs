﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ScottPlot.Cookbook.XmlDocumentation
{
    public class DocumentedParameter
    {
        public string Name;
        public string Type;
        public string Summary;
    }
}
