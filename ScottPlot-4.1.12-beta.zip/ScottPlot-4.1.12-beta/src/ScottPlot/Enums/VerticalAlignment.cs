﻿namespace ScottPlot
{
    public enum VerticalAlignment
    {
        Upper,
        Lower,
        Middle
    }
}
