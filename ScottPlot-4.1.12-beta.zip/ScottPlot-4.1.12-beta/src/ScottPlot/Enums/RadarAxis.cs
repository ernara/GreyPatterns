﻿namespace ScottPlot
{
    public enum RadarAxis
    {
        Circle,
        Polygon,
        None
    }
}
