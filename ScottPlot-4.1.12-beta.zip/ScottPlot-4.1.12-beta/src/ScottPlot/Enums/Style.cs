﻿namespace ScottPlot
{
    public enum Style
    {
        Default,
        Control,
        Blue1,
        Blue2,
        Blue3,
        Light1,
        Light2,
        Gray1,
        Gray2,
        Black,
        Seaborn
    }
}
