﻿namespace ScottPlot.Ticks
{
    public enum DateTimeUnit { ThousandYear, HundredYear, TenYear, Year, Month, Day, Hour, Minute, Second, Decisecond, Centisecond, Millisecond };
}
