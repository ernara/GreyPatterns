**New Contributors:**
please review [CONTRIBUTING.md](https://github.com/swharden/ScottPlot/blob/master/CONTRIBUTING.md)

**Purpose:**
Describe what this pull request accomplishes. If it addresses an issue, link to it here.

**New Functionality:**
Describe what this pull request does using code and/or images.

```cs
var newThing = new SpecialObject();
```