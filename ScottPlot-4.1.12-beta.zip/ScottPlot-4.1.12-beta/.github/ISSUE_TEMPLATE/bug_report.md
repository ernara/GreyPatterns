---
name: Bug report
about: Create a report to help us improve
title: ''
labels: 'BUG'
assignees: ''

---
### Your Environment
- ScottPlot Version:
- Operating System:
- Is it a GUI app? What platform?
    - Platforms include WinForms, WPF, and Avalonia

Describe the bug and how we can reproduce it.

```cs
// a code sample may improve communication
```