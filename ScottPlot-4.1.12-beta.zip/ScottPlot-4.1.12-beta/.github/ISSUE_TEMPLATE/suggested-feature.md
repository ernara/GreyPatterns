---
name: Idea / Feature Request
about: Let us know how ScottPlot can be improved
title: ''
labels: 'Feature'
assignees: ''

---

**What can we do to make ScottPlot better?**
Consider if code examples or images would help communicate your request.

The [ScottPlot Roadmap](https://github.com/swharden/ScottPlot/blob/master/dev/roadmap.md) may provide additional context regarding current goals and future directions.